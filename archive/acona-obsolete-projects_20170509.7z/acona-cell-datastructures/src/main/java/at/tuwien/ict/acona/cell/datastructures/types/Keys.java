package at.tuwien.ict.acona.cell.datastructures.types;

public enum Keys {
	SERVICE,
	MODE;
}
