package at.tuwien.ict.acona.cell.datastructures.types;

public enum AconaSync {
	SYNCHRONIZED,
	ASYNCHRONIZED;
}
