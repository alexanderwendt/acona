package at.tuwien.ict.acona.cell.datastructures.types;

public enum AconaServiceType {
	NONE,
	READ,
	WRITE,
	SUBSCRIBE,
	UNSUBSCRIBE,
	QUERY,
	DEBUG;
}
