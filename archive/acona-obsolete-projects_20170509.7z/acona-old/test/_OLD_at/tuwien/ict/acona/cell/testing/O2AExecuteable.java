package _OLD_at.tuwien.ict.acona.cell.testing;

import jade.core.Agent;

public interface O2AExecuteable {
	void run(Agent agent);
}
