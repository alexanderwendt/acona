package at.tuwien.ict.acona.jadelauncher.datastructurecontainer;

public enum GatewayMode {
	ASYNC,
	SYNC;
}
