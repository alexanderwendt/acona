package at.tuwien.ict.acona.jadelauncher.util;

public class JadeException extends Exception {

	public JadeException(String message) {
		super(message);
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
