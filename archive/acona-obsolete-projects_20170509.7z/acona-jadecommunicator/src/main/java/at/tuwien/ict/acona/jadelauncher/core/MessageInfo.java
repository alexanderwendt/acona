package at.tuwien.ict.acona.jadelauncher.core;

public class MessageInfo {
	public final static String SYNCREQUEST = "EXTERNALSYNCREQUEST";
	public final static String ACKNOWLEDGE = "ACKNOWLEDGE";
}
